#!/bin/bash
echo "deal with container"
if [ ! -z "$(docker container ls -a -q)" ]; then
	docker container stop $(docker container ls -a -q)
	docker container rm $(docker container ls -a -q)
	echo "clear container success"
else
	echo "container empty"
fi

echo "deal with image"
if [ ! -z "$(docker image ls -a -q)" ]; then	
	docker image rm $(docker image ls -a -q)
	echo "clear image success"
else
	echo "image empty"
fi


